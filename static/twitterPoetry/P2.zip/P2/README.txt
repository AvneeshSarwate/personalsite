To run this program, you must first install nltk using 'pip install nltk'.

Once nltk is installed, you need to install a handfull of nltk packages. 
This can be done by running the Python script "install_nltk_packages.py" 

Then, start the server with the command:

> python twitterpoetryserver.py

and go to localhost:6310 in the browser. 

On my system, this is running with Python 2.7.13 on macOS Sierra with Google Chrome 61